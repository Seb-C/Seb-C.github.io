/*
C'est une base de petit jeu de plafetorme multijoueurs. Ce n'est pas terminé, mais en le publiant, j'estpère qu'il sera utile à quelqu'un ...
Copyright (C) 2012 Sébastien CAPARROS (http://www.sebastien-caparros.name/ or contact@sebastien-caparros.name)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.grizzly.http.server.NetworkListener;
import org.glassfish.grizzly.http.server.ServerConfiguration;
import org.glassfish.grizzly.http.server.StaticHttpHandler;
import org.glassfish.grizzly.websockets.WebSocketAddOn;
import org.glassfish.grizzly.websockets.WebSocketEngine;


/**
 * @author Sébastien CAPARROS
 * One Class to rule them all, One Class to find them,
 * One Class to run them all and in the darkness bind them.
 */
public class Main {

	/**
	 * Default port for HTTP server when not specified in config.ini
	 */
	public final static int DEFAULT_SERVER_PORT = 8080;

	/**
	 * Default map name when not specified in config.ini
	 */
	public final static String DEFAULT_MAP = "default";
	
	/**
	 * Default debug mode (browser's doesn't uses a cache)
	 */
	public final static boolean DEFAULT_DEBUG_MODE = false;

	/**
	 * Properties object, containing config.ini configuration
	 */
	public static Properties config;

	/**
	 * @param args nothing
	 */
	public static void main(String[] args) {
		// Checking if config.ini file exists
		File configFile = new File("config.ini");
		Main.config = new Properties();
		if(configFile.exists()) {
			// Loading config.ini into a Properties object
			try {
				FileInputStream propertiesFile = new FileInputStream(configFile);
				Main.config.load(propertiesFile);
				propertiesFile.close();
			} catch (IOException e) {
				e.printStackTrace();
				System.exit(0);
			}
		} else {
			System.err.println("File config.ini not found. Default values will be used.");
		}

		// Loading server port from config file
		int serverPort;
		if(Main.config.containsKey("SERVER_PORT")) {
			try {
				serverPort = Integer.parseInt((String) Main.config.get("SERVER_PORT"));
			} catch(NumberFormatException e) {
				System.err.println("SERVER_PORT must be a valid port number in config.ini. Using default " + Main.DEFAULT_SERVER_PORT + ".");
				serverPort = Main.DEFAULT_SERVER_PORT;
				Main.config.put("SERVER_PORT", String.valueOf(serverPort));
			}
		} else {
			System.err.println("SERVER_PORT not specified in config.ini. Using default " + Main.DEFAULT_SERVER_PORT + ".");
			serverPort = Main.DEFAULT_SERVER_PORT;
			Main.config.put("SERVER_PORT", String.valueOf(serverPort));
		}

		// Loading Default map name
		String mapName;
		if(Main.config.containsKey("DEFAULT_MAP")) {
			mapName = (String) Main.config.get("DEFAULT_MAP");
		} else {
			System.err.println("DEFAULT_MAP not specified in config.ini. Using default " + Main.DEFAULT_MAP + ".");
			mapName = Main.DEFAULT_MAP;
			Main.config.put("DEFAULT_MAP", String.valueOf(mapName));
		}

		// Loading debug mode state
		boolean debugMode;
		if(Main.config.containsKey("DEBUG_MODE")) {
			debugMode = Boolean.parseBoolean((String) Main.config.get("DEBUG_MODE"));
		} else {
			System.err.println("DEBUG_MODE not specified in config.ini. Using default " + Main.DEFAULT_DEBUG_MODE + ".");
			debugMode = Main.DEFAULT_DEBUG_MODE;
			Main.config.put("DEBUG_MODE", String.valueOf(debugMode));
		}
		
		// Saving new configuration
		// Loading config.ini into a Properties object
		try {
			FileOutputStream propertiesFile = new FileOutputStream(configFile);
			Main.config.store(propertiesFile, null);
			propertiesFile.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}
		
		// ... And there was Light.
		World world = new World(mapName);
		
		// Creating server
		final HttpServer server = new HttpServer();
		NetworkListener networkListener = new NetworkListener(
			"play", 
			"localhost", 
			serverPort
		);
		server.addListener(networkListener);
		ServerConfiguration serverConfiguration = server.getServerConfiguration();
		
		// HTTP Handlers for dynamic and static files
		HttpDynamicHandler httpDynamicHandler = new HttpDynamicHandler(world);
		StaticHttpHandler httpStaticHandler   = new StaticHttpHandler("./www");
		serverConfiguration.addHttpHandler(httpDynamicHandler, "/dynamic");
		serverConfiguration.addHttpHandler(httpStaticHandler, "/");
		httpStaticHandler.setFileCacheEnabled(!debugMode);
		
		// WebSockets server
		GameServer gameServer = new GameServer(world);
		WebSocketAddOn webSocketAddon = new WebSocketAddOn();
		networkListener.registerAddOn(webSocketAddon);
		WebSocketEngine.getEngine().register(gameServer);
		
		try {
			server.start();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		// FIXME don't stop server if main ends ?!?
		while(true) {
			try {
				Thread.sleep(Long.MAX_VALUE);
			} catch (InterruptedException ex) {}
		}
	}
}
