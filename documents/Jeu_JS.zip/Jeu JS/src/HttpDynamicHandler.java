/*
C'est une base de petit jeu de plafetorme multijoueurs. Ce n'est pas terminé, mais en le publiant, j'estpère qu'il sera utile à quelqu'un ...
Copyright (C) 2012 Sébastien CAPARROS (http://www.sebastien-caparros.name/ or contact@sebastien-caparros.name)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.imageio.ImageIO;
import org.glassfish.grizzly.http.server.HttpHandler;
import org.glassfish.grizzly.http.server.Request;
import org.glassfish.grizzly.http.server.Response;
import org.glassfish.grizzly.http.util.Header;


public class HttpDynamicHandler extends HttpHandler {

	/**
	 * The game contents
	 */
	protected World world;

	public HttpDynamicHandler(World world) {
		super();
		this.world = world;
	}
	
	public void service(Request request, Response response) throws Exception {
		String resource = request.getRequestURI();
		
		// No cache for dynamic resources
		SimpleDateFormat format = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz");
		response.setHeader(Header.Pragma, "no-cache");
		response.setHeader(Header.Expires, "0");
		response.setHeader(Header.LastModified, format.format(new Date()));
		response.setHeader(Header.CacheControl, "no-cache, must-revalidate");
		
		// Sending document
		if(resource.equals("/dynamic/map/scene.gif")) {
			this.sendGIFImage(response, this.world.getMapSceneImage());
		} else if(resource.equals("/dynamic/map/walls.gif")) {
			this.sendGIFImage(response, this.world.getMapWallsImage());
		} else {
			response.sendError(404);
		}
	}

	private void sendGIFImage(Response response, BufferedImage image) throws IOException {
		response.setContentType("image/gif");
		ImageIO.write(image, "gif", response.getNIOOutputStream());
		// TODO exception when sending images (after 2 or 3 tries)
	}
}
