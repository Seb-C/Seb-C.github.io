/*
C'est une base de petit jeu de plafetorme multijoueurs. Ce n'est pas terminé, mais en le publiant, j'estpère qu'il sera utile à quelqu'un ...
Copyright (C) 2012 Sébastien CAPARROS (http://www.sebastien-caparros.name/ or contact@sebastien-caparros.name)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

import java.net.InetSocketAddress;
import java.util.Date;
import java.util.HashMap;
import org.glassfish.grizzly.http.HttpRequestPacket;
import org.glassfish.grizzly.websockets.DataFrame;
import org.glassfish.grizzly.websockets.WebSocket;
import org.glassfish.grizzly.websockets.WebSocketAddOn;
import org.glassfish.grizzly.websockets.WebSocketApplication;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * @author Sébastien CAPARROS
 */
public class GameServer extends WebSocketApplication {

	/**
	 * Active player list
	 */
	private HashMap<WebSocket, Client> clients;

	/**
	 * The Game World
	 */
	private World world;

	/**
	 * @param world The Game World
	 */
	public GameServer(World world) {
		this.clients = new HashMap<WebSocket, Client>();
		this.world = world;
	}

	public void onClose(WebSocket client, DataFrame frame) {
		try {
			JSONObject data = new JSONObject();
			data.put("id", client.hashCode());
			this.sendBroadcast("removePlayer", data, client);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		System.out.println("WS : [" + new Date().toString() + ", " + client + "] Disconnected");
		this.clients.remove(client);
	}

	public boolean onError(WebSocket client, Throwable t) {
		t.printStackTrace();
		try {
			JSONObject data = new JSONObject();
			data.put("id", client.hashCode());
			data.put("withError", true);
			this.sendBroadcast("removePlayer", data, client);
		} catch (JSONException e1) {
			e1.printStackTrace();
		}
		System.out.println("WS : [" + new Date().toString() + ", " + client + "] Connection lost");
		this.clients.remove(client);
		
		return true;
	}
	
	public boolean isApplicationRequest(HttpRequestPacket hrp) {
		return true;
	}
	
	public void onMessage(WebSocket client, DataFrame frame) {
		this.onMessage(client, frame.getTextPayload());
	}
	
	public void onMessage(WebSocket client, byte[] bytes) {
		this.onMessage(client, new String(bytes));
	}
	
	public void onMessage(WebSocket client, String text) {
		try {
			// Parsing message
			JSONObject message = new JSONObject(text);
			String action = message.getString("action");
			JSONObject data = message.getJSONObject("data");
			JSONObject temp;

			// Handling message request
			if(action.equals("setName")) {
				this.getPlayer(client).changeName(data.getString("name"));
			} else if(action.equals("setState")) {
				Entity character = getPlayer(client).getCharacter();
				character.setPosition(JSONObjectToPoint(data.getJSONObject("position")));
				character.setVelocity(JSONObjectToPoint(data.getJSONObject("velocity")));
				character.setMoving(data.getBoolean("isMoving"));
				// If no exceptions has occured, we are here and the message is safe
				data.put("id", client.hashCode());
				this.sendBroadcast(action, data, client);
			} else {
				System.err.println("Unknown action received from server : " + action);
			}

		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
	}

	public void onConnect(WebSocket client) {
		try {
			JSONObject data = new JSONObject();
			data.put("id", client.hashCode());
			this.sendTo(client, "yourIdIs", data);
		} catch (JSONException e) {
			e.printStackTrace();
			return;
		}
		System.out.println("WS : [" + new Date().toString() + ", " + client + "] Connection");

		// Setting players to this new client
		for(WebSocket w : this.clients.keySet()) {
			Client c = this.clients.get(w);
			int id = w.hashCode();

			// Defining player name
			try {
				JSONObject data = new JSONObject();
				data.put("id", id);
				data.put("name", c.getName());
				this.sendTo(client, "setName", data);
			} catch (JSONException e) {
				e.printStackTrace();
				continue;
			}

			// Creating character
			Entity character = c.getCharacter();
			if(character != null) {
				try {
					JSONObject data = new JSONObject();
					data.put("id", id);
					data.put("position", character.getPosition().toMap());
					data.put("sprite", character.getSpriteUrl());
					data.put("velocity", character.getVelocity().toMap());
					this.sendTo(client, "setCharacter", data);
				} catch (JSONException e) {
					e.printStackTrace();
					continue;
				}
			}
		}

		this.clients.put(client, new Client(client, this));
	}
	
	/**
	 * Creates a Point from a JSONObject coitaining x and y values
	 * @param o A JSONObject containing x and y values
	 * @return The Point object
	 * @throws JSONException If JSONObject doesn't contains valid x or y
	 */
	private Point JSONObjectToPoint(JSONObject o) throws JSONException {
		return new Point(
			o.getInt("x"), 
			o.getInt("y")
		);
	}
	
	/**
	 * Creates the JSON stringified message from action and data
	 * @param action The action name
	 * @param data Details of the action
	 * @return A valid JSON String
	 * @throws JSONException -
	 */
	private String createRawMessage(String action, JSONObject data) throws JSONException {
		JSONObject message = new JSONObject();
		message.put("action", action);
		message.put("data", data);

		return message.toString();
	}

	/**
	 * Sends the message to a WebSocket
	 * @param w The targetted WebSocket
	 * @param action The action name
	 * @param data Details of the action
	 */
	public void sendTo(WebSocket w, String action, JSONObject data) {
		try {
			w.send(this.createRawMessage(action, data));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Sends the message to a Player
	 * @param p The targetted Player
	 * @param action The action name
	 * @param data Details of the action
	 */
	public void sendTo(Client p, String action, JSONObject data) {
		this.sendTo(p.getWebSocket(), action, data);
	}

	/**
	 * Sends the message to a Player
	 * @param playerName The targetted WebSocket
	 * @param action The action name
	 * @param data Details of the action
	 */
	public void sendTo(String playerName, String action, JSONObject data) {
		this.sendTo(this.getPlayer(playerName), action, data);
	}

	/**
	 * Sends a message to everybody
	 * @param action The action name
	 * @param data Details of the action
	 */
	public void sendBroadcast(String action, JSONObject data) {
		String message;
		try {
			message = this.createRawMessage(action, data);
		} catch (JSONException e) {
			e.printStackTrace();
			return;
		}
		for(WebSocket w : this.clients.keySet()) {
			try {
				w.send(message);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Sends a message to everybody, excepted the specified WebSocket
	 * @param action The action name
	 * @param data Details of the action
	 * @param exceptWebSocket Message will not be send to this WebSocket
	 */
	public void sendBroadcast(String action, JSONObject data, WebSocket exceptWebSocket) {
		String message;
		try {
			message = this.createRawMessage(action, data);
		} catch (JSONException e) {
			e.printStackTrace();
			return;
		}
		for(WebSocket w : this.clients.keySet()) {
			if(w != exceptWebSocket) {
				try {
					w.send(message);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * Sends a message to everybody, excepted the specified Player
	 * @param action The action name
	 * @param data Details of the action
	 * @param exceptPlayer Message will not be send to this Player
	 */
	public void sendBroadcast(String action, JSONObject data, Client exceptPlayer) {
		this.sendBroadcast(action, data, exceptPlayer.getWebSocket());
	}

	/**
	 * Sends a message to everybody, excepted the specified Player
	 * @param action The action name
	 * @param data Details of the action
	 * @param exceptPlayerName Message will not be send to this Player
	 */
	public void sendBroadcast(String action, JSONObject data, String exceptPlayerName) {
		this.sendBroadcast(action, data, this.getPlayer(exceptPlayerName));
	}

	/**
	 * @param w The associated WebSocket
	 * @return the Player associated to the WebSocket
	 */
	public Client getPlayer(WebSocket w) {
		return this.clients.get(w);
	}

	/**
	 * @param playerName Name of the Player to find
	 * @return The Player object or null when not found
	 */
	public Client getPlayer(String playerName) {
		for(WebSocket w : this.clients.keySet()) {
			Client p = this.clients.get(w);
			String n = p == null ? null : p.getName();
			if(n != null && n.equals(playerName)) {
				return p;
			}
		}
		return null;
	}

}
