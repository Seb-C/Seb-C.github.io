/*
C'est une base de petit jeu de plafetorme multijoueurs. Ce n'est pas terminé, mais en le publiant, j'estpère qu'il sera utile à quelqu'un ...
Copyright (C) 2012 Sébastien CAPARROS (http://www.sebastien-caparros.name/ or contact@sebastien-caparros.name)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;


public class World {

	/**
	 * Where to find the map files
	 */
	public final static String MAP_ROOT = "./maps/";

	private String mapName;

	private File sceneFile;

	private File wallFile;

	private BufferedImage sceneBufferedImage;

	private BufferedImage wallBufferedImage;

	private CustomImage sceneImage;

	private CustomImage wallsImage;

	public World(String mapName) {
		this.mapName = mapName;

		// Files
		this.sceneFile = new File(MAP_ROOT + "/" + mapName + "/scene.gif");
		this.wallFile = new File(MAP_ROOT + "/" + mapName + "/walls.gif");

		// Loading Images
		try {
			this.sceneBufferedImage = ImageIO.read(this.sceneFile);
			this.wallBufferedImage = ImageIO.read(this.wallFile);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}

		// CustomImage objects
		this.sceneImage = new CustomImage(this.sceneBufferedImage);
		this.wallsImage = new CustomImage(this.wallBufferedImage);
	}

	public BufferedImage getMapSceneImage() {
		return this.sceneImage.getImage();
	}

	public BufferedImage getMapWallsImage() {
		return this.wallsImage.getImage();
	}

}
