/*
C'est une base de petit jeu de plafetorme multijoueurs. Ce n'est pas terminé, mais en le publiant, j'estpère qu'il sera utile à quelqu'un ...
Copyright (C) 2012 Sébastien CAPARROS (http://www.sebastien-caparros.name/ or contact@sebastien-caparros.name)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/**
 * @author Sébastien CAPARROS
 * This objects only contains basic physical attributes of entity
 */
public class Entity {
	/**
	 * The url of the entity's sprite
	 */
	private String spriteUrl;

	/**
	 * The position of the entity (middle point)
	 */
	private Point position;

	/**
	 * The current velocity
	 */
	private Point velocity;
	
	/**
	 * When the player is moving, there is no deceleration
	 */
	private boolean isMoving;

	/**
	 * The size of the entity. Can be null (null = size determined by the sprite image size)
	 */
	private Point size;

	/**
	 * @param position The position of the entity
	 * @param spriteUrl The sprite of the entity, or null
	 * @param size The size of the point. Can be null (null = size determined by the sprite image size)
	 */
	public Entity(Point position, String spriteUrl, Point size) {
		this.spriteUrl = spriteUrl;
		this.setPosition(position);
		this.size = size == null ? null : size.clone();
		this.isMoving = false;
		this.setVelocity(new Point(0, 0));
	}

	/**
	 * Returns the position of the entity
	 * @return The position of the entity
	 */
	public Point getPosition() {
		return this.position.clone();
	}

	/**
	 * Changes the position of the entity
	 * @param position The new position of the entity (middle point)
	 */
	public void setPosition(Point position) {
		this.position = position.clone();
	}

	/**
	 * Returns the current velocity of the object
	 * @return the current velocity
	 */
	public Point getVelocity() {
		return this.velocity.clone();
	}

	/**
	 * Changes the velocity of the object
	 * @param velocity The new velocity
	 */
	public void setVelocity(Point velocity) {
		this.velocity = velocity == null ? null : velocity.clone();
	}
	
	/**
	 * Is the entity moving ?
	 * @return True when moving
	 */
	public boolean isMoving() {
		return isMoving;
	}
	
	/**
	 * Sets the moving state of the entity
	 * @param isMoving True when moving
	 */
	public void setMoving(boolean isMoving) {
		this.isMoving = isMoving;
	}

	/**
	 * Returns the url of the sprite
	 * @return The url of the sprite (can be null)
	 */
	public String getSpriteUrl() {
		return this.spriteUrl;
	}

	/**
	 * Returns the size of the entity
	 * @return The size of the entity (can be null if it's determined by sprite size)
	 */
	public Point getSize() {
		return this.size.clone();
	}
}
