/*
C'est une base de petit jeu de plafetorme multijoueurs. Ce n'est pas terminé, mais en le publiant, j'estpère qu'il sera utile à quelqu'un ...
Copyright (C) 2012 Sébastien CAPARROS (http://www.sebastien-caparros.name/ or contact@sebastien-caparros.name)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

import java.util.HashMap;
import java.util.Map;


/**
 * @author Sébastien CAPARROS
 * Represents a Point, with x and y values (integers)
 */
public class Point implements Cloneable {

	/**
	 * The x value
	 */
	public int x;

	/**
	 * The y value
	 */
	public int y;

	/**
	 * Creates the Point using x and y
	 * @param x The x value
	 * @param y The y value
	 */
	public Point(int x, int y) {
		this.x = x;
		this.y = y;
	}

	/**
	 * Creates a Point with x = 0 and y = 0
	 */
	public Point() {
		this.x = 0;
		this.y = 0;
	}

	/**
	 * @see java.lang.Object#clone()
	 */
	@Override
	public Point clone() {
		return new Point(
			this.x,
			this.y
		);
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "(" + this.x + ", " + this.y + ")";
	}

	/**
	 * Changes the Point to a map
	 * @return A map containing x and y values
	 */
	public Map<String, Integer> toMap() {
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		map.put("x", this.x);
		map.put("y", this.y);
		return map;
	}

}
