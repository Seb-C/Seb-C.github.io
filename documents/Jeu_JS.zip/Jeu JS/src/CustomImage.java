/*
C'est une base de petit jeu de plafetorme multijoueurs. Ce n'est pas terminé, mais en le publiant, j'estpère qu'il sera utile à quelqu'un ...
Copyright (C) 2012 Sébastien CAPARROS (http://www.sebastien-caparros.name/ or contact@sebastien-caparros.name)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;


public class CustomImage {

	private BufferedImage image;

	private Graphics2D graphics;

	public CustomImage(BufferedImage image) {
		this.image = image;
		this.graphics = (Graphics2D) this.image.getGraphics();
	}

	/**
	 * @param x The x position of the pixel
	 * @param y The y position of the pixel
	 * @return 4 RGBA components, between 0 and 255
	 */
	public int[] getPixel(int x, int y) {
		int argb = this.image.getRGB(x, y);
		return new int[] {
				argb >> 16 & 0xFF,
				argb >> 8 & 0xFF,
				argb & 0xFF,
				argb >> 24 & 0xFF,
		};
	}

	public void clearCircle(int x, int y, int radius) {
		// TODO implement (same than JS)
	}

	public BufferedImage getImage() {
		return this.image;
	}

}
