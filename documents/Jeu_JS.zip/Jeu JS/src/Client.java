/*
C'est une base de petit jeu de plafetorme multijoueurs. Ce n'est pas terminé, mais en le publiant, j'estpère qu'il sera utile à quelqu'un ...
Copyright (C) 2012 Sébastien CAPARROS (http://www.sebastien-caparros.name/ or contact@sebastien-caparros.name)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

import org.glassfish.grizzly.websockets.WebSocket;
import org.json.JSONException;
import org.json.JSONObject;


/**
 * @author Sébastien CAPARROS
 */
public class Client {

	/**
	 * WebSocket associated to the Client
	 */
	private WebSocket socket;

	/**
	 * Server object
	 */
	private GameServer server;

	/**
	 * The name of the player (null while loading)
	 */
	private String name;

	/**
	 * The client's character, as an Entity
	 */
	private Entity character;

	/**
	 * Creates a Player associated to a WebSocket
	 * @param socket WebSocket associated to the Client
	 * @param server Server object
	 */
	public Client(WebSocket socket, GameServer server) {
		this.socket = socket;
		this.server = server;
		this.name = null;
		this.character = null;
	}

	/**
	 * Changes the player name
	 * @param newName The new Name
	 */
	public void changeName(String newName) {
		// Name can't be null and has to be different than current name
		if(newName == null || newName.equals(this.name)) {
			return;
		}

		// When the name already exists, adding a number
		if(this.server.getPlayer(newName) != null) {
			newName = newName + "_" + Integer.toString(this.socket.hashCode(), 36);
		}

		int id = this.socket.hashCode();

		// Changing or setting (= connection) name
		try {
			JSONObject data = new JSONObject();
			data.put("id", id);
			data.put("name", newName);
			this.server.sendBroadcast("setName", data);
		} catch (JSONException e) {
			e.printStackTrace();
			return;
		}

		if(this.name == null) {
			// Creating character
			// TODO dynamic sprite and spawn point
			this.character = new Entity(new Point(840, 1100), "./sprites/persotest.png", null);

			// Sending character
			try {
				JSONObject data = new JSONObject();
				data.put("id", id);
				data.put("position", this.character.getPosition().toMap());
				data.put("sprite", this.character.getSpriteUrl());
				this.server.sendBroadcast("setCharacter", data);
			} catch (JSONException e) {
				e.printStackTrace();
				return;
			}
		}
		this.name = newName;
	}
	
	/**
	 * Returns the player's character
	 * @return The player's character (as an entity)
	 */
	public Entity getCharacter() {
		return this.character;
	}

	/**
	 * @return WebSocket associated to the Player
	 */
	public WebSocket getWebSocket() {
		return this.socket;
	}

	/**
	 * @return The name of the player (null while loading)
	 */
	public String getName() {
		return this.name;
	}

}
