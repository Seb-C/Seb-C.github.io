/*
C'est une base de petit jeu de plafetorme multijoueurs. Ce n'est pas terminé, mais en le publiant, j'estpère qu'il sera utile à quelqu'un ...
Copyright (C) 2012 Sébastien CAPARROS (http://www.sebastien-caparros.name/ or contact@sebastien-caparros.name)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/**
 * 
 */
var BasicParticle = function(world, position) {
	this.position = position;
	this.world = world;
	this.velocity = new Point(0, 0);
	this.world.addParticle(this);
	this.color = "black";
	this.lastMoveTime = Date.now + 1000;
};

BasicParticle.prototype.refresh = function(currentTime, timePassedMultiplicator) {
	if(!this.world || !this.world.wallsImageLoaded) {
		return;
	}
	
	// Applying gravity strength (acceleration of the earth's gravity = 9.80665 m/s)
	this.velocity.y += 98 * timePassedMultiplicator;
	
	// Distance moved
	var distance = new Point(
		/*Math.floor*/(this.velocity.x * timePassedMultiplicator),
		/*Math.floor*/(this.velocity.y * timePassedMultiplicator)
	);
	
	// Updating position
	var futurePosition = this.position.add(distance, true);
	
	// Collisions
	if(this.world.wallsImage.isWall(futurePosition.x, futurePosition.y)) {
		var part = Math.max(distance.x, distance.y);
		for(var i = 0 ; i < part ; i++) {
			var currentX = this.position.x + /*Math.round*/(distance.x / part) * i;
			var currentY = this.position.y + /*Math.round*/(distance.y / part) * i;
			if(this.world.wallsImage.isWall(currentX, currentY)) {
				futurePosition.x = currentX;
				futurePosition.y = currentY;
				this.velocity.y = 0;
				break;
			}
		}
	}
	
	if(futurePosition.equals(this.position)) {
		if(this.world.wallsImage.isWall(futurePosition.x, futurePosition.y + 1)) {
			// Checking if there is a slope
			if(!this.world.wallsImage.isWall(futurePosition.x + 3, futurePosition.y + 1)) {
				this.velocity.x = 20;
				this.velocity.y += 20;
			} else if(!this.world.wallsImage.isWall(futurePosition.x - 3, futurePosition.y + 1)) {
				this.velocity.x = -20;
				this.velocity.y += 20;
			}
		}
	} else {
		this.lastMoveTime = currentTime;
		this.position = futurePosition;
	}
	
	if(currentTime - this.lastMoveTime >= 1000) {
		// Particle is dead
		this.color = "red";
		this.world.freezeParticle(this);
	}
	
	// Decelerating
	//this.velocity.x *= 0.975;
};
