/*
C'est une base de petit jeu de plafetorme multijoueurs. Ce n'est pas terminé, mais en le publiant, j'estpère qu'il sera utile à quelqu'un ...
Copyright (C) 2012 Sébastien CAPARROS (http://www.sebastien-caparros.name/ or contact@sebastien-caparros.name)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/**
 * Easy image loading, aditing and printing
 * @param {HTMLImageElement} DOMImage A DOM Image object
 */
var CustomImage = function(DOMImage) {
	this.DOMImage = DOMImage;
	this.width = DOMImage.width;
	this.height = DOMImage.height;
	
	// Creating canvas
	this.DOMCanvas = document.createElement('canvas');
	this.DOMCanvas.width = this.width;
	this.DOMCanvas.height = this.height;
	//document.body.appendChild(this.DOMCanvas); // Debug
	
	// Writing image to the canvas
	this.context = this.DOMCanvas.getContext('2d');
	this.context.drawImage(DOMImage, 0, 0);
	
	// Pixels cache
	this.updateImageData();
};

/**
 * Updating pixel cache. Call this function after each change on the image
 */
CustomImage.prototype.updateImageData = function() {
	this.imageData = this.context.getImageData(0, 0, this.width, this.height).data;
}

/**
 * @param {int} x The x position of the pixel
 * @param {int} y The y position of the pixel
 * @return {Array} 4 RGBA components, between 0 and 255
 */
CustomImage.prototype.getPixel = function(x, y) {
	var index = (y * this.width + x) * 4;
	return [
		this.imageData[index],		// Red
		this.imageData[index + 1],	// Green
		this.imageData[index + 2],	// Blue
		this.imageData[index + 3]	// Alpha
	];
};

/**
 * Returns the canvas of the editor
 * @return {DOMCanvasElement} The canvas
 */
CustomImage.prototype.getCanvas = function() {
	return this.DOMCanvas;
};

/**
 * Returns the context of the editor
 * @return {DOM2DContext} The context
 */
CustomImage.prototype.getContext = function() {
	return this.context;
};

/**
 * Empties a circle on the map (e.g. for an explosion)
 * @param {int} x Center of the circle
 * @param {int} y Center of the circle
 * @param {int} radius Circle's radius
 */
CustomImage.prototype.clearCircle = function(x, y, radius) {
	var xRounded = Math.round(x);
	var yRounded = Math.round(y);
	var roundedRadius = Math.round(radius);
	
	this.context.save();
	this.context.globalCompositeOperation = 'destination-out';
	this.context.fillStyle = "#00000000";
	this.context.arc(xRounded, yRounded, roundedRadius, 0, 2 * Math.PI);
	this.context.fill();
	this.context.restore();
	this.context.closePath();
	
	this.updateImageData();
};

/**
 * Adding method to context objects to allow CustomImage drawing 
 * @see drawImage documentation (same thing but with a CustomImage)
 */
CanvasRenderingContext2D.prototype.drawCImage = function(CImage, p1, p2, p3, p4, p5, p6, p7, p8) {
	switch(arguments.length) {
		case 3 : 
			this.drawImage(CImage.getCanvas(), p1, p2);
			break;
		case 5 : 
			this.drawImage(CImage.getCanvas(), p1, p2, p3, p4);
			break;
		case 9 : 
			this.drawImage(CImage.getCanvas(), p1, p2, p3, p4, p5, p6, p7, p8);
			break;
		default : 
			this.drawImage(CImage.getImage(), p1, p2, p3, p4, p5, p6, p7, p8);
	}
};
