/*
C'est une base de petit jeu de plafetorme multijoueurs. Ce n'est pas terminé, mais en le publiant, j'estpère qu'il sera utile à quelqu'un ...
Copyright (C) 2012 Sébastien CAPARROS (http://www.sebastien-caparros.name/ or contact@sebastien-caparros.name)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/**
 * An entity
 * @param {DOMContext2D} context Where to draw entity
 * @param {World} world The world where the entity is
 * @param {Point} position Spawn point
 * @param {String} spriteUrl URL Of the sprite image
 * @param {Point} size Entity size
 * @param {int} rotation Angle of the entity, as degrees (optional)
 */
var Entity = function(context, world, position, spriteUrl, size, rotation) {
	this.context = context;
	this.position = position;
	this.world = world;
	this.velocity = new Point(0, 0);
	this.size = size || new Point(10, 10);
	
	// When entity is moving, there is no deceleration
	this._isMoving = false;
	
	this.rotation = (rotation % 360) || 0;
	if(this.rotation < 0) this.rotation = 360 + this.rotation;
	
	this.spriteImageLoaded = false;
	this.spriteImage = null;
	if(spriteUrl != null) {
		this.spriteDOMImage = new Image();
		this.spriteDOMImage.entityObjectRef = this;
		this.spriteDOMImage.addEventListener('load', function() {
			this.entityObjectRef.spriteImage = new CustomImage(this);
			this.entityObjectRef.spriteImageLoaded = true;
			this.entityObjectRef.size = new Point(
				this.width,
				this.height
			);
			
			this.entityObjectRef.world.addEntity(this.entityObjectRef);
		});
		this.spriteDOMImage.src = spriteUrl;
	}
	
	// TODO more physics
	// TODO collision between entities ?
};

Entity.prototype.destroy = function() {
	this.world.removeEntity(this);
};

/**
 * Applies a strength to move entity
 * @param {int} angle Strength direction (0 .. 359)
 * @param {int} strength Strength value
 */
Entity.prototype.applyLinearForce = function(angle, strength) {
	// Asserting that angle is between 0 and 360
	var trueAngle = angle % 360;
	if(trueAngle < 0) trueAngle = 360 + trueAngle;
	
	// Determining axis proportion from angle
	var axisParts = new Point();
	// X axis
	if(trueAngle < 180) {
		axisParts.x = 1 - (Math.abs(trueAngle - 90) / 90);
	} else {
		axisParts.x = -(1 - (Math.abs(trueAngle - 270) / 90));
	}
	// Y axis
	if(trueAngle < 90) {
		axisParts.y = 1 - (trueAngle / 90);
	} else if(trueAngle >= 270) {
		axisParts.y = (trueAngle - 270) / 90;
	} else {
		axisParts.y = -(1 - (Math.abs(trueAngle - 180) / 90));
	}
	
	// Multiplying it by strength
	var velocityToAdd = axisParts.multiply(strength, true);
	
	// Applying strength
	this.velocity.add(velocityToAdd);
};

/**
 * Update physics, independently of time passed since last call.
 */
Entity.prototype.refresh = function(currentTime, timePassedMultiplicator) {
	var stairsHeightLimitPart = 0.1;
	
	if(!this.world || !this.world.wallsImageLoaded) {
		return;
	}
	
	// Applying gravity strength (acceleration of the earth's gravity = 9.80665 m/s)
	this.velocity.y += 98 * timePassedMultiplicator;
	
	// Distance moved
	var distance = new Point(
		this.velocity.x * timePassedMultiplicator,
		this.velocity.y * timePassedMultiplicator
	);
	
	// Debug security
	if(!isFinite(distance.x) || !isFinite(distance.y)) {
		throw new Error("Infinite distance bug !");
	}
	
	// Updating position
	var futurePosition = this.position.add(distance, true);
	
	// Determining position of the rectangle's angles
	var radiansAngle = Math.PI * (this.rotation) / 180;
	var trigonometricRadiansAngle = -radiansAngle;
	var cosAngle = Math.cos(trigonometricRadiansAngle);
	var sinAngle = Math.sin(trigonometricRadiansAngle);
	var halfSize = this.size.multiply(0.5, true);
	var rectanglePoints = new Array(
		new Point(
			-halfSize.x * cosAngle - -halfSize.y * sinAngle + futurePosition.x,
			-halfSize.x * sinAngle + -halfSize.y * cosAngle + futurePosition.y
		),
		new Point(
			halfSize.x * cosAngle - -halfSize.y * sinAngle + futurePosition.x,
			halfSize.x * sinAngle + -halfSize.y * cosAngle + futurePosition.y
		),
		new Point(
			halfSize.x * cosAngle - halfSize.y * sinAngle + futurePosition.x,
			halfSize.x * sinAngle + halfSize.y * cosAngle + futurePosition.y
		),
		new Point(
			-halfSize.x * cosAngle - halfSize.y * sinAngle + futurePosition.x,
			-halfSize.x * sinAngle + halfSize.y * cosAngle + futurePosition.y
		)
	);
	var vertices = new Array(
		{a: rectanglePoints[0], b: rectanglePoints[1], sideAngle: 0  },
		{a: rectanglePoints[1], b: rectanglePoints[2], sideAngle: 90 },
		{a: rectanglePoints[2], b: rectanglePoints[3], sideAngle: 180},
		{a: rectanglePoints[3], b: rectanglePoints[0], sideAngle: 270}
	);
	
	// Function to handle collisions
	var handleCollision = function(wallsImage, velocity, x, y, sideAngle) {
		var isWall = wallsImage.isWall(x, y);
		
		if(isWall) {
			if(sideAngle >= 315 && sideAngle < 45) {
				// Top side
				if(velocity.y < 0) {
					velocity.y = 0;
				}
				if(distance.y < 0) {
					// Collision detected --> searching from exact position
					for(var i = 0 ; i > distance.y ; i--) {
						var pos = Math.round(futurePosition.y - halfSize.y - distance.y + i);
						if(wallsImage.isWall(x, pos)) {
							futurePosition.y = pos + halfSize.y;
							distance.y = i;
							break;
						}
					}
				}
			} else if(sideAngle >= 45 && sideAngle < 135) {
				// right side
				if(velocity.x > 0) {
					velocity.x = 0;
				}
				if(distance.x > 0) {
					// Collision detected --> searching from exact position
					for(var i = 0 ; i < distance.x ; i++) {
						var pos = Math.round(futurePosition.x + halfSize.x - distance.x + i);
						if(wallsImage.isWall(pos, y)) {
							futurePosition.x = pos - halfSize.x - 1;
							distance.x = i;
							break;
						}
					}
				}
			} else if(sideAngle >= 135 && sideAngle < 225) {
				// Bottom side
				if(velocity.y > 0) {
					velocity.y = 0;
				}
				if(distance.y > 0) {
					// Collision detected --> searching from exact position
					for(var i = 0 ; i < distance.y ; i++) {
						var pos = Math.round(futurePosition.y + halfSize.y - distance.y + i);
						if(wallsImage.isWall(x, pos)) {
							futurePosition.y = pos - halfSize.y;
							distance.y = i;
							break;
						}
					}
				}
			} else {
				// Left side
				if(velocity.x < 0) {
					velocity.x = 0;
				}
				if(distance.x < 0) {
					// Collision detected --> searching from exact position
					for(var i = 0 ; i > distance.x ; i--) {
						var pos = Math.round(futurePosition.x - halfSize.x - distance.x + i);
						if(wallsImage.isWall(pos, y)) {
							futurePosition.x = pos + halfSize.x + 1;
							distance.x = i;
							break;
						}
					}
				}
			}
		}
		
		return isWall;
	};
	
	// Variables for stairs calculation
	var symbol = this.velocity.x > 0 ? 1 : -1; // -1 = left, +1 = right
	var minY = rectanglePoints[0].y;
	var maxY = minY;
	for(var i = 1 ; i < rectanglePoints.length ; i++) {
		var currentY = rectanglePoints[i].y;
		if(currentY < minY) minY = currentY;
		if(currentY > maxY) maxY = currentY;
	}
	var heightLimit = Math.ceil(stairsHeightLimitPart * (maxY - minY));
	
	// Detection of the collisions with the scene walls
	for(var i = 0 ; i < vertices.length ; i++) {
		// a and b point of the segment to check
		var a = vertices[i].a;
		var b = vertices[i].b;
		
		// Angle of the side
		var sideAngle = vertices[i].sideAngle + this.rotation;
		// Asserting that angle is between 0 and 360
		sideAngle = sideAngle % 360;
		if(sideAngle < 0) sideAngle = 360 + sideAngle;
		
		if(a.x == b.x) {
			// Segment is perfectly vertical
			var begin = Math.min(a.y, b.y);
			var end = Math.max(a.y, b.y);
			// Checking collision
			for(var y = begin ; y < end ; y++) {
				if(handleCollision(this.world.wallsImage, this.velocity, a.x, y, sideAngle)) {
					break;
				}
			}
			
			// Stairs
			var xAdjacent = a.x + symbol;
			var currentY = end - heightLimit;
			var yDifference = 0;
			while(currentY < end) {
				if(this.world.wallsImage.isWall(xAdjacent, currentY)) {
					yDifference = currentY - (end - heightLimit);
					break;
				} else {
					currentY++;
				}
			}
			futurePosition.y -= yDifference;
		} else {
			var slope = (b.y - a.y) / (b.x - a.x); // slope = Coefficient directeur
			var begin = Math.min(a.x, b.x);
			var end = Math.max(a.x, b.x);
			if(begin != a.x) begin++; // Debug
			for(var x = begin ; x < end ; x++) {
				var y = a.y + (x * slope);
				if(handleCollision(this.world.wallsImage, this.velocity, x, y, sideAngle)) {
					break;
				}
			}
		}
	}
	
	// FIXME : can climb walls when flooding jump and left/right
	
	this.position = futurePosition;
	
	// Decelerating if not moving
	if(!this._isMoving) {
		this.velocity.x *= 0.975;
	}
};

/**
 * Draws the entity on the canvas
 * If the entity doesn't have a sprite, a rectangle will be drawn
 */
Entity.prototype.drawOnContext = function(cameraDifference) {
	var topLeftX = Math.round(this.position.x + cameraDifference.x);
	var topLeftY = Math.round(this.position.y + cameraDifference.y);
	var radiansAngle = this.rotation * (Math.PI / 180);
	
	this.context.save();
	this.context.translate(topLeftX, topLeftY);
	this.context.rotate(radiansAngle);
	if(this.spriteImageLoaded) {
		this.context.drawCImage(this.spriteImage, -this.size.x / 2, -this.size.y / 2);
	} else {
		this.context.fillRect(-this.size.x / 2, -this.size.y / 2, this.size.x, this.size.y);
	}
	this.context.restore();
};

/**
 * When entity is moving, there is no deceleration
 * @param {boolean} isMoving The moving state
 */
Entity.prototype.setMoving = function(isMoving) {
	this._isMoving = isMoving;
};

/**
 * Returns the moving state
 * @return {boolean} The moving state
 */
Entity.prototype.isMoving = function() {
	return this._isMoving;
};

/**
 * Changes the current speed of the entity
 * @param {Point} velocity The new speed
 */
Entity.prototype.setVelocity = function(velocity) {
	this.velocity = velocity.clone();
};
Entity.prototype.setVelocityX = function(x) { this.velocity.x = x; };
Entity.prototype.setVelocityY = function(y) { this.velocity.y = y; };

/**
 * Changes the current position of the entity
 * @param {Point} position The new position
 */
Entity.prototype.setPosition = function(position) {
	this.position = position.clone();
};
Entity.prototype.setPositionX = function(x) { this.position.x = x; };
Entity.prototype.setPositionY = function(y) { this.position.y = y; };

/**
 * Returns the current speed of the entity
 * @return {Point} The current speed
 */
Entity.prototype.getVelocity = function() {
	return this.velocity.clone();
};
Entity.prototype.getVelocityX = function() { return this.velocity.x; };
Entity.prototype.getVelocityY = function() { return this.velocity.y; };

/**
 * Returns the current position of the entity
 * @return {Point} The current position
 */
Entity.prototype.getPosition = function() {
	return this.position.clone();
};
Entity.prototype.getPositionX = function() { return this.position.x; };
Entity.prototype.getPositionY = function() { return this.position.y; };

