/*
C'est une base de petit jeu de plafetorme multijoueurs. Ce n'est pas terminé, mais en le publiant, j'estpère qu'il sera utile à quelqu'un ...
Copyright (C) 2012 Sébastien CAPARROS (http://www.sebastien-caparros.name/ or contact@sebastien-caparros.name)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/**
 * A point ...
 * @param {int} x X position
 * @param {int} y Y position
 */
var Point = function(x, y) {
	this.x = x || 0;
	this.y = y || 0;
};

/**
 * To combine two Point
 * @param {int|Point} x When it's an integer, the value will be added to x and y.
 * @param {boolean} mustReturn true when value have to be returned, false or undefined to update current Point
 * @return {Point|null} The new Point when mustReturn is true
 */
Point.prototype.add = function(x, mustReturn) {
	var objectToModify = mustReturn ? this.clone() : this;
	
	if(x instanceof Point) {
		objectToModify.x += x.x;
		objectToModify.y += x.y;
	} else {
		objectToModify.x += x;
		objectToModify.y += x;
	}
	
	return mustReturn ? objectToModify : null;
};

/**
 * Multiply two points
 * @param {int|Point} x When it's an integer, the value will be multiplied to x and y.
 * @param {boolean} mustReturn true when value have to be returned, false or undefined to update current Point
 * @return {Point|null} The new Point when mustReturn is true
 */
Point.prototype.multiply = function(x, mustReturn) {
	var objectToModify = mustReturn ? this.clone() : this;
	
	if(x instanceof Point) {
		objectToModify.x *= x.x;
		objectToModify.y *= x.y;
	} else {
		objectToModify.x *= x;
		objectToModify.y *= x;
	}
	
	return mustReturn ? objectToModify : null;
};

Point.prototype.round = function() {
	return new Point(
		Math.round(this.x),
		Math.round(this.y)
	);
};

/**
 * Applies f to x and y
 * @param {callback} f A function, which takes only one parameters, and returns another
 * @param {Point} p If the function implies another Point. Else, unspecified.
 */
Point.prototype.apply = function(f, p) {
	if(p) {
		this.x = f(this.x, p.x);
		this.y = f(this.y, p.y);
	} else {
		this.x = f(this.x);
		this.y = f(this.y);
	}
};

Point.prototype.clone = function() {
	return new Point(this.x, this.y);
};

Point.prototype.equals = function(p) {
	return this.x == p.x 
		&& this.y == p.y;
};

Point.prototype.toString = function() {
	return "(" + this.x + ", " + this.y + ")";
};
