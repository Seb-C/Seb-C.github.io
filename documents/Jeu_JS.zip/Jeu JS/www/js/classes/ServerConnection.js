/*
C'est une base de petit jeu de plafetorme multijoueurs. Ce n'est pas terminé, mais en le publiant, j'estpère qu'il sera utile à quelqu'un ...
Copyright (C) 2012 Sébastien CAPARROS (http://www.sebastien-caparros.name/ or contact@sebastien-caparros.name)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/**
 * Connection to WebSocket server
 * @param {String} serverName As domainNameOrIp:port 
 */
var ServerConnection = function(serverName) {
	this.world = null;
	
	// Connecting
	this.socket = new WebSocket("ws://" + serverName + "/play");
	
	// TODO use a polyfill for websockets
	
	// Defining actions
	this.socket.serverConnectionObjectRef = this;
	this.socket.addEventListener('open', function() {
		this.serverConnectionObjectRef.changePlayerName();
	});
	this.socket.addEventListener('message', function(event) {
		var message = JSON.parse(event.data);
		
		this.serverConnectionObjectRef._onMessage(message.action, message.data);
	});
	this.socket.addEventListener('close', function(event) { 
		alert("Connection lost :(");
	});
	
	this.id = null;
	
	// Other players details
	this.players = {
		name: new Array(),
		character: new Array()
	};
};

ServerConnection.prototype.setWorld = function(world) {
	this.world = world;
};

/**
 * What to do with message
 * @param {String} action What to do
 * @param {Object} data Anything related to the action. Can also be null
 */
ServerConnection.prototype._onMessage = function(action, data) {
	/*
	 * yourIdIs(id)
	 * setName(id, name)
	 * setCharacter(id, position, sprite, velocity) --> + connection message
	 */
	
	switch(action) {
		case "yourIdIs" : 
			this.id = data.id;
			break;
		case "setName" : 
			this.players.name[data.id] = data.name;
			if(data.id == this.id) {
				if(this.players.name[this.id]) {
					addChatMessage("Name changed (" + data.name + ").", "font-weight: bold;");
				} else {
					addChatMessage("Welcome, " + data.name + " !", "font-weight: bold;");
				}
			} else {
				addChatMessage(data.name + " is now connected.", "font-weight: bold;");
			}
			break;
		case "setCharacter" : 
			var character;
			if(this.players.character[data.id]) {
				// To update
				character = this.players.character[data.id];
			} else {
				// Adding
				character = new Entity(
					this.world.context, 
					this.world, 
					new Point(data.position.x, data.position.y), 
					data.sprite
				);
				
				this.players.character[data.id] = character;
				if(data.id == this.id) {
					this.world.camera.setTarget(character);
				}
			}
			
			// TODO don't list all players as "now connected" when connecting
			
			// Changing physic settings
			if(data.position) {
				character.setPosition(new Point(data.position.x, data.position.y));
			}
			if(data.velocity) {
				character.setVelocity(new Point(data.velocity.x, data.velocity.y));
			}
			break;
		case "setState" : 
			var character = this.players.character[data.id];
			character.setPosition(new Point(data.position.x, data.position.y));
			character.setVelocity(new Point(data.velocity.x, data.velocity.y));
			character.setMoving(data.isMoving);
			break;
		case "removePlayer" : 
			var disconnectDetails = data.withError ? "has lost his connection" : "has left the game";
			addChatMessage(this.players.name[data.id] + " " + disconnectDetails + ".", "font-weight: bold;");
			delete this.players.name[data.id];
			if(this.players.character[data.id]) {
				this.players.character[data.id].destroy();
				delete this.players.character[data.id];
			}
			break;
		default : 
			throw new Error("Unknown action received from server : " + action);
	}
};

/**
 * Sends a message to the server
 * @param {String} action What to do
 * @param {Object} data Anything related to the action. Can also be null
 */
ServerConnection.prototype._send = function(action, data) {
	var message = JSON.stringify({"action": action, "data": data});
	this.socket.send(message);
};

/**
 * Sends a query to change or to set the current player's name
 */
ServerConnection.prototype.changePlayerName = function() {
	var newName = window.configuration.getPlayerName();
	this._send("setName", {'name': newName});
};

/**
 * Sends the current player state (velocity and position) to the server
 */
ServerConnection.prototype.sendPlayerState = function() {
	var thisPlayer = this.players.character[this.id];
	var currentState = {
		"position": thisPlayer.getPosition(),
		"velocity": thisPlayer.getVelocity(),
		"isMoving": thisPlayer.isMoving()
	};
	this._send("setState", currentState);
};
