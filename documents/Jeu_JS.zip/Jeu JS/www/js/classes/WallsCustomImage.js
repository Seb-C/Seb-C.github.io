/*
C'est une base de petit jeu de plafetorme multijoueurs. Ce n'est pas terminé, mais en le publiant, j'estpère qu'il sera utile à quelqu'un ...
Copyright (C) 2012 Sébastien CAPARROS (http://www.sebastien-caparros.name/ or contact@sebastien-caparros.name)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/**
 * Managesthe image containing informations about walls 
 * @param {HTMLImageElement} DOMImage A DOM Image object
 * @extends CustomImage
 */
var WallsCustomImage = function(DOMImage) {
	/*
	 * transparent : void
	 * black : walls
	 * idead : 
	 * - black = non breakable wall
	 * - white = breakable wall
	 * - other colors for other options :D ?
	 * - play with colour addressing ?
	 */
	
	// Extending CustomImage
	this.__proto__.constructor(DOMImage);
};
WallsCustomImage.prototype = CustomImage.prototype;

/**
 * Fills a rectangle in the cache array
 * @param {int} x The x position of the rectangle (left side)
 * @param {int} y The y position of the rectangle (top side)
 * @param {int} w The width of the rectangle
 * @param {int} h The height of the rectangle
 * @param {Array} c Array containing the 4 color components (rgba)
 */
WallsCustomImage.prototype.setRectangle = function(x, y, w, h, c) {
	for(var i = x, li = x + w ; i < li ; i++) {
		for(var j = y, lj = y + h ; j < lj ; j++) {
			var index = (j * this.width + x) * 4;
			this.imageData[index    ] = c[0];
			this.imageData[index + 1] = c[1];
			this.imageData[index + 2] = c[2];
			this.imageData[index + 3] = c[3];
		}
	}
};

/**
 * Checks if there is a wall here
 * @param {int} x Pixel position
 * @param {int} y Pixel position
 * @return {boolean} True if it's a wall
 */
WallsCustomImage.prototype.isWall = function(x, y) {
	// Out of bounds = wall
	if(x < 0 || x > this.width || y < 0 || y > this.height) return true;
	
	var xRounded = Math.round(x);
	var yRounded = Math.round(y);
	var index = (yRounded * this.width + xRounded) * 4 + 3;
	
	return (this.imageData[index] == 255);
};
