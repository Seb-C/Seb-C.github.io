/*
C'est une base de petit jeu de plafetorme multijoueurs. Ce n'est pas terminé, mais en le publiant, j'estpère qu'il sera utile à quelqu'un ...
Copyright (C) 2012 Sébastien CAPARROS (http://www.sebastien-caparros.name/ or contact@sebastien-caparros.name)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/**
 * The camera. Initialised to free mode
 */
var Camera = function() {
	this.isFree = true;
	// Free camera : using targetPoint. Else : using targetCharacter.position
	this.targetCharacter = null;
	this.lastCharacterVelocity = null;
	this.targetPoint = new Point(); // TODO set the position in free mode
	
	this.keys = [];
	window.cameraObjectRef = this;
	window.addEventListener('keydown', function(e) {
		var event = e || window.event;
		var key = event.keyCode || event.which;
		cameraObjectRef.keys[key] = true;
		
		// Cancelling default action
		event.preventDefault();
	});
	window.addEventListener('keyup', function(e) {
		var event = e || window.event;
		var key = event.keyCode || event.which;
		cameraObjectRef.keys[key] = false;
		
		// Cancelling default action
		event.preventDefault();
	});
};

// TODO prefix private and protected methods/attributes with "_" and ???

/**
 * Returns the current camera target position
 */
Camera.prototype.getPosition = function() {
	if(this.isFree) {
		return this.targetPoint.clone();
	} else {
		return this.targetCharacter.position.clone();
	}
};

/**
 * Set the camera in free mode
 */
Camera.prototype.setFree = function() {
	this.isFree = true;
	this.targetPoint = this.targetCharacter.position.clone();
};

/**
 * Changes the target of the camera
 * @param {Character} character The character to focus on
 */
Camera.prototype.setTarget = function(character) {
	this.isFree = false;
	this.targetCharacter = character;
};

/**
 * Handles camera or character, depending on current keyboard state (moving ...)
 * Needs a preRefresh before world updating
 */
Camera.prototype.refresh = function() {
	var sendPlayerState = false;
	
	var isLeft  = this.keys[window.configuration.getKeyboard("Left")];
	var isRight = this.keys[window.configuration.getKeyboard("Right")];
	var isUp    = this.keys[window.configuration.getKeyboard("Up")];
	var isDown  = this.keys[window.configuration.getKeyboard("Down")];
	
	var movingVelocity = 40;
	
	if(isLeft) {
		if(this.isFree) {
			this.targetPoint.x -= 100;
		} else {
			if(!this.targetCharacter.isMoving()
				|| this.targetCharacter.getVelocityX() == movingVelocity
				|| this.targetCharacter.getVelocityX() == 0
			) {
				this.targetCharacter.setMoving(true);
				this.targetCharacter.setVelocityX(-movingVelocity);
			}
		}
	} else if(!isRight) {
		if(!this.isFree && this.targetCharacter.getVelocityX() >= 0 
			            && this.targetCharacter.isMoving()) {
			sendPlayerState = true;
			this.targetCharacter.setMoving(false);
		}
	}
	if(isUp) {
		if(this.isFree) {
			this.targetPoint.y -= 100;
		} else {
			if(this.targetCharacter.getVelocityY() == 0) {
				this.targetCharacter.setVelocityY(-100);
				soundTest("/sounds/jump.ogg");
				sendPlayerState = true;
			}
		}
	}
	if(isRight) {
		if(this.isFree) {
			this.targetPoint.x += 100;
		} else {
			if(!this.targetCharacter.isMoving() 
				|| this.targetCharacter.getVelocityX() == -movingVelocity
				|| this.targetCharacter.getVelocityX() == 0
			) {
				sendPlayerState = true;
				this.targetCharacter.setMoving(true);
				this.targetCharacter.setVelocityX(movingVelocity);
			}
		}
	} else if(!isLeft) {
		if(!this.isFree && this.targetCharacter.getVelocityX() <= 0 
			            && this.targetCharacter.isMoving()) {
			sendPlayerState = true;
			this.targetCharacter.setMoving(false);
		}
	}
	if(isDown) {
		if(this.isFree) {
			this.targetPoint.y += 100;
		}
	}
	
	// Sends current player state to the server (and other clients)
	if(!this.isFree && sendPlayerState) {
		window.server.sendPlayerState();
	}
};
