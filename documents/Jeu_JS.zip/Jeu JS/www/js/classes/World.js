/*
C'est une base de petit jeu de plafetorme multijoueurs. Ce n'est pas terminé, mais en le publiant, j'estpère qu'il sera utile à quelqu'un ...
Copyright (C) 2012 Sébastien CAPARROS (http://www.sebastien-caparros.name/ or contact@sebastien-caparros.name)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/**
 * Loads and shows the world into DOM context
 * @param {CanvasRendering2DContext} context DOM 2D Context, where to draw the world
 */
var World = function(context) {
	this.context = context;
	this.camera = new Camera();
	this.entities = new Array();
	this.particles = new Array();
	this.lastRefresh = Date.now();
	
	// Loading map scene
	this.sceneImageLoaded = false;
	this.sceneImage = null;
	this.sceneDOMImage = new Image();
	this.sceneDOMImage.worldObjectRef = this;
	this.sceneDOMImage.addEventListener('load', function() {
		this.worldObjectRef.sceneImage = new CustomImage(this);
		this.worldObjectRef.sceneImageLoaded = true;
	});
	this.sceneDOMImage.src = "/dynamic/map/scene.gif";
	
	// Loading map walls
	this.wallsImageLoaded = false;
	this.wallsImage = null;
	this.wallsDOMImage = new Image();
	this.wallsDOMImage.worldObjectRef = this;
	this.wallsDOMImage.addEventListener('load', function() {
		this.worldObjectRef.wallsImage = new WallsCustomImage(this);
		this.worldObjectRef.wallsImageLoaded = true;
	});
	this.wallsDOMImage.src = "/dynamic/map/walls.gif";
};

/**
 * Adds an entity to the world
 * @param {Entity} entity The entity to add
 */
World.prototype.addEntity = function(entity) {
	this.entities.push(entity);
};

/**
 * Removes an entity from the world
 * @param {Entity} entity The entity
 */
World.prototype.removeEntity = function(entity) {
	this.entities.splice(this.entities.indexOf(entity), 1);
};

/**
 * Adds a particle to the world
 * @param {Particle} particle The particle to add
 */
World.prototype.addParticle = function(particle) {
	this.particles.push(particle);
};

/**
 * Removes a particle from the world
 * @param {Particle} particle The particle
 */
World.prototype.removeParticle = function(particle) {
	this.particles.splice(this.particles.indexOf(particle), 1);
};

World.prototype.freezeParticle = function(particle) {
	this.removeParticle(particle);
	
	var x = Math.round(particle.position.x);
	var y = Math.round(particle.position.y - 3);
	
	var sceneContext = this.sceneImage.getContext();
	var wallsContext = this.wallsImage.getContext();
	
	sceneContext.fillStyle = particle.color;
	wallsContext.fillStyle = "black";
		
	sceneContext.fillRect(x, y, 3, 3);
	sceneContext.fill();
	wallsContext.fillRect(x, y, 3, 3); // Useless ?
	this.wallsImage.setRectangle(x, y, 3, 3, [0, 0, 0, 255]);
};

/**
 * Refreshes all entities and particles
 */
World.prototype.refresh = function() {
	// Getting passed time since the last call
	var currentTime = Date.now();
	var timePassed = currentTime - this.lastRefresh;
	this.lastRefresh = currentTime;
	var timePassedMultiplicator = timePassed / 1000;
	
	for(var i = 0, l = this.entities.length ; i < l ; i++) {
		this.entities[i].refresh(currentTime, timePassedMultiplicator);
	}
	
	// Can't optimize this.particles.length because it can change 
	// (when removing a particle while looping)
	for(var i = 0 ; i < this.particles.length ; i++) {
		this.particles[i].refresh(currentTime, timePassedMultiplicator);
	}
};

/**
 * Redraws the world on the context
 */
World.prototype.drawOnContext = function() {
	// Determining camera position
	var cameraDifference = this.camera.getPosition();
	cameraDifference.multiply(-1);
	cameraDifference.add(window.canvasSize.multiply(0.5, true));
	
	// Drawing scene
	if(this.sceneImageLoaded) {
		this.context.drawCImage(this.sceneImage, cameraDifference.x, cameraDifference.y);
	}
	
	// Drawing entities
	for(var i = 0, l = this.entities.length ; i < l ; i++) {
		this.entities[i].drawOnContext(cameraDifference);
	}
	
	// Drawing particles
	this.context.beginPath();
	for(var i = 0, l = this.particles.length ; i < l ; i++) {
		var p = this.particles[i].position.add(cameraDifference, true);
		this.context.fillStyle = this.particles[i].color;
		this.context.fillRect(p.x - 1, p.y - 1, 3, 3);
	}
	this.context.closePath();
	this.context.fill();
};
