/*
C'est une base de petit jeu de plafetorme multijoueurs. Ce n'est pas terminé, mais en le publiant, j'estpère qu'il sera utile à quelqu'un ...
Copyright (C) 2012 Sébastien CAPARROS (http://www.sebastien-caparros.name/ or contact@sebastien-caparros.name)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/**
 * Contains the configuration of the player (keys, volume, player name ...)
 * @param {DOMElement} _DOMContainer The DOM element which will contain the configuration controls
 * @param {DOMElement} _DOMShowButton The DOM element which wil bo the button to show/hide configuration panel
 */
var Configuration = function(DOMContainer, DOMShowButton) {
	if(localStorage.getItem("initialized") == null) {
		this._playerName  = "Guest";
		this._musicVolume = 1;
		this._soundVolume = 1;
		this._keyboard    = {
			"Left":  37, // 37 = Left arrow
			"Right": 39, // 39 = Right arrow
			"Up":    38, // 38 = Up arrow
			"Down":  40  // 40 = Down arrow
		};
		this._save();
	} else {
		this._playerName  = localStorage.getItem("playerName");
		this._musicVolume = parseFloat(localStorage.getItem("musicVolume"));
		this._soundVolume = parseFloat(localStorage.getItem("soundVolume"));
		this._keyboard    = JSON.parse(localStorage.getItem("keyboard"));
	}
	
	this._DOMContainer = DOMContainer;
	this._DOMShowButton = DOMShowButton;
	this._createConfigurationPanel();
	this._createConfigurationButton();
	
	this._currentKeyToChange = null;
	this._currentKeyController = null;
};

/**
 * Saves all configuration to local storage
 */
Configuration.prototype._save = function() {
	localStorage.setItem("playerName",  this._playerName);
	localStorage.setItem("musicVolume", this._musicVolume);
	localStorage.setItem("soundVolume", this._soundVolume);
	localStorage.setItem("keyboard", JSON.stringify(this._keyboard));
	localStorage.setItem("initialized", true);
};

Configuration.prototype.getPlayerName  = function() { return this._playerName;    };
Configuration.prototype.getMusicVolume = function() { return this._musicVolume;   };
Configuration.prototype.getSoundVolume = function() { return this._soundVolume;   };
Configuration.prototype.getKeyboard = function(key) { return this._keyboard[key]; };

Configuration.prototype.setPlayerName = function(name) {
	// TODO change player name without reloading page
	this._playerName = name;
	this._save();
};
Configuration.prototype.setMusicVolume = function(volume) {
	// TODO change volume without reloading page
	this._musicVolume = volume;
	this._save();
};
Configuration.prototype.setSoundVolume = function(volume) {
	this._soundVolume = volume;
	this._save();
};
Configuration.prototype.setKeyboard = function(key, keyCode) {
	this._keyboard[key] = keyCode;
	this._save();
};

/**
 * Configures the configuration button (which shows or hides the configuration panel)
 */
Configuration.prototype._createConfigurationButton = function() {
	var that = this;
	this._DOMShowButton.addEventListener("click", function() {
		with(that._DOMContainer) {
			setAttribute("data-visible", getAttribute("data-visible") == "true" ? false : true);
		}
	});
};

/**
 * Creates the configuration controls
 */
Configuration.prototype._createConfigurationPanel = function() {
	var that = this;
	
	// Title
	var title = document.createElement("h1");
	title.appendChild(document.createTextNode("Sound configuration"));
	this._DOMContainer.appendChild(title);
	
	// Player name controller
	var div = document.createElement("div");
	div.appendChild(document.createTextNode("Your name : "));
	var nameControl = document.createElement("input");
	nameControl.setAttribute("type", "button");
	nameControl.setAttribute("value", this._playerName);
	nameControl.addEventListener("click", function() {
		var newName = prompt("What's your new name ?", this.value);
		if(newName) {
			this.value = newName;
			that.setPlayerName(newName);
		}
	});
	div.appendChild(nameControl);
	this._DOMContainer.appendChild(div);
	
	// Music volume controller
	div = document.createElement("div");
	div.appendChild(document.createTextNode("Music volume : "));
	var musicControl = document.createElement("input");
	musicControl.setAttribute("type", "range");
	musicControl.setAttribute("value", this._musicVolume);
	musicControl.setAttribute("min",   0);
	musicControl.setAttribute("max",   1);
	musicControl.setAttribute("step",  0.05);
	musicControl.addEventListener("change", function() {
		that.setMusicVolume(parseFloat(this.value));
	});
	div.appendChild(musicControl);
	this._DOMContainer.appendChild(div);
	
	// Sound volume controller
	div = document.createElement("div");
	div.appendChild(document.createTextNode("Sound volume : "));
	var soundControl = document.createElement("input");
	soundControl.setAttribute("type", "range");
	soundControl.setAttribute("value", this._soundVolume);
	soundControl.setAttribute("min",   0);
	soundControl.setAttribute("max",   1);
	soundControl.setAttribute("step",  0.05);
	soundControl.addEventListener("change", function() {
		that.setSoundVolume(parseFloat(this.value));
	});
	div.appendChild(soundControl);
	this._DOMContainer.appendChild(div);
	
	title = document.createElement("h1");
	title.appendChild(document.createTextNode("Keyboard configuration"));
	this._DOMContainer.appendChild(title);
	
	// Keys change
	window.addEventListener('keyup', function(e) {
		var event = e || window.event;
		if(that._currentKeyToChange !== null) {
			var key = event.keyCode || event.which;
			that.setKeyboard(that._currentKeyToChange, key);
			that._currentKeyToChange = null;
			var keyName = window.keyNames[key] ? window.keyNames[key] : "KEY_" + key;
			that._currentKeyController.value = keyName;
			that._currentKeyController = null;
			event.stopPropagation();
		}
		event.preventDefault();
	});
	
	for(var keyDescription in this._keyboard) {
		var key = this._keyboard[keyDescription];
		var keyName = window.keyNames[key] ? window.keyNames[key] : "KEY_" + key;
		
		div = document.createElement("div");
		div.appendChild(document.createTextNode(keyDescription + " : "));
		var keyControl = document.createElement("input");
		keyControl.setAttribute("type",         "button");
		keyControl.setAttribute("value",        keyName);
		keyControl.setAttribute("data-keyName", keyDescription);
		keyControl.addEventListener("click", function() {
			that._currentKeyController = this;
			that._currentKeyToChange = this.getAttribute("data-keyName");
			this.value = "...";
		});
		div.appendChild(keyControl);
		this._DOMContainer.appendChild(div);
	}
	
	// TODO don't allow double assignation for one key
	// TODO gamepads
};
