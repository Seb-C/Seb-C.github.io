/*
C'est une base de petit jeu de plafetorme multijoueurs. Ce n'est pas terminé, mais en le publiant, j'estpère qu'il sera utile à quelqu'un ...
Copyright (C) 2012 Sébastien CAPARROS (http://www.sebastien-caparros.name/ or contact@sebastien-caparros.name)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/**
 * Adds a message to the chat box
 * @param {String} message The message to send (HTML will be automatically filtered)
 * @param {String} style The css style of the message (optional)
 */
function addChatMessage(message, style) {
	// Creating message box
	var div = document.createElement('div');
	var txtNode = document.createTextNode(message);
	div.appendChild(txtNode);
	div.setAttribute('style', style);
	
	// Adding it to chat box
	var chat = document.getElementById('chat');
	chat.appendChild(div);
	if(!chat.hasFocus) {
		// Scrolling to the message (only if necessary)
		chat.scrollTop = chat.scrollHeight;
	}
}

function musicTest(fileName) {
	var audio = document.createElement("audio");
	audio.loop = true;
	audio.volume = window.configuration.getMusicVolume();
	audio.src = fileName;
	audio.play();
}
function soundTest(fileName) {
	var audio = document.createElement("audio");
	audio.loop = false;
	audio.volume = window.configuration.getSoundVolume();
	audio.src = fileName;
	
	// Useless while not included in document
	//audio.addEventListener('ended', function() { /* Remove element */ });
	
	audio.play();
}


/**
 * Debug function. Unlimited number of parameters can be passed
 */
function print_r(/* any objects, any type, any quantity */) {
	var s = "";
	var seen = [];
	for(i = 0 ; i < arguments.length ; i++) {
		if(i != 0) {
			s += "\n\n";
		}
		s += JSON.stringify(
			arguments[i], 
			function(key, val) {
				if (typeof val == "object") {
					if (seen.indexOf(val) >= 0)
						return undefined;
					seen.push(val);
				}
				return val;
			}
		);
	}
	
	// Showing it in the debut container
	var container = document.getElementById('print_r');
	if(container !== null) {
		container.innerHTML = s;
	}
}

// TODO use a polyfill instead
// @author https://developer.mozilla.org/en-US/docs/DOM/Using_full-screen_mode
function toggleFullScreen() {
	var r = false;
	if ((document.fullScreenElement && document.fullScreenElement !== null) ||    // alternative standard method
	   (!document.mozFullScreen && !document.webkitIsFullScreen)) {               // current working methods
		if (document.documentElement.requestFullScreen) {
			document.documentElement.requestFullScreen();
			r = true;
		} else if (document.documentElement.mozRequestFullScreen) {
			document.documentElement.mozRequestFullScreen();
			r = true;
		} else if (document.documentElement.webkitRequestFullScreen) {
			document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT);
			r = true;
		}
	} else {
		if (document.cancelFullScreen) {
			document.cancelFullScreen();
		} else if (document.mozCancelFullScreen) {
			document.mozCancelFullScreen();
		} else if (document.webkitCancelFullScreen) {
			document.webkitCancelFullScreen();
		}
	}
	return r;
}
