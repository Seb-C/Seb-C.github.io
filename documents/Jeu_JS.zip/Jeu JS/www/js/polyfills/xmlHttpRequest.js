if(!window.XMLHttpRequest) {
	window.XMLHttpRequest = function () {
		try {
			return new ActiveXObject("Msxml2.XMLHTTP.6.0"); 
		} catch (e) {
			try {
				return new ActiveXObject("Msxml2.XMLHTTP.3.0"); 
			} catch (e) {
				try {
					return new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					throw new Error("XMLHttpRequest not supported !");
				}
			}
		}
	};
	XMLHttpRequest.UNSENT = 0;
	XMLHttpRequest.OPENED = 1;
	XMLHttpRequest.HEADERS_RECEIVED = 2;
	XMLHttpRequest.LOADING = 3;
	XMLHttpRequest.DONE = 4;
}